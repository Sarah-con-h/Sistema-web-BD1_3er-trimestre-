<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../app/views/shared/header.php';


$p = $_GET['p'] ?? 'home';

if ($p === 'login') {
    require_once __DIR__ . '/../app/controllers/AuthController.php';
    $ctrl = new AuthController();
    $ctrl->login();
} elseif ($p === 'register') {
    require_once __DIR__ . '/../app/controllers/AuthController.php';
    $ctrl = new AuthController();
    $ctrl->register();
} elseif ($p === 'logout') {
    require_once __DIR__ . '/../app/controllers/AuthController.php';
    $ctrl = new AuthController();
    $ctrl->logout();
} elseif ($p === 'trips') {
    require_once __DIR__ . '/../app/controllers/TripController.php';
    $ctrl = new TripController();
    $action = $_GET['action'] ?? 'index';
    if (!method_exists($ctrl, $action)) $action = 'index';
    $ctrl->$action();
} elseif ($p === 'reservations') {
    require_once __DIR__ . '/../app/controllers/ReservationController.php';
    $ctrl = new ReservationController();
    $action = $_GET['action'] ?? 'index';
    if (!method_exists($ctrl, $action)) $action = 'index';
    $ctrl->$action();
} elseif ($p === 'users') {
    require_once __DIR__ . '/../app/controllers/UserController.php';
    $ctrl = new UserController();
    $action = $_GET['action'] ?? 'index';
    if (!method_exists($ctrl, $action)) $action = 'index';
    $ctrl->$action();
} elseif ($p === 'admin/dashboard') {
    require_once __DIR__ . '/../app/views/admin/dashboard.php';
} elseif ($p === 'empleado/dashboard') {
    require_once __DIR__ . '/../app/views/empleado/dashboard.php';
} elseif ($p === 'cliente/dashboard') {
    require_once __DIR__ . '/../app/views/cliente/dashboard.php';
} else {
    // Establecer el tipo de contenido como HTML
    header('Content-Type: text/html; charset=UTF-8');
    
    echo "
    <!DOCTYPE html>
    <html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Gestor de Reservaciones</title>

    <!-- ✅ Tailwind CSS (CDN oficial y funcional) -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Fuente Poppins -->
    <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap' rel='stylesheet'>
</head>

    <body class=\"font-[Poppins]\">
    
    <div class='min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-100 via-blue-100 to-purple-100'>
        <div class='bg-white/80 backdrop-blur-md shadow-2xl rounded-2xl p-10 text-center border border-white/40 transition-transform duration-300 hover:scale-[1.02] w-full max-w-md'>
            
            <h1 class='text-3xl font-extrabold text-gray-800 mb-4 tracking-wide'>
                🌍 Bienvenido a <span class='text-indigo-600'>Gestor de Reservaciones</span>
            </h1>

            <p class='text-gray-600 mb-8 text-lg'>
                Por favor selecciona una opción para continuar:
            </p>

            <div class='flex flex-col sm:flex-row gap-4 justify-center'>
                <a href='?p=login' 
                    class='px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-semibold rounded-lg shadow-md hover:shadow-lg hover:opacity-90 transition duration-300'>
                    🔑 Iniciar Sesión
                </a>

                <a href='?p=register' 
                    class='px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-semibold rounded-lg shadow-md hover:shadow-lg hover:opacity-90 transition duration-300'>
                    📝 Registrarse
                </a>

                <a href='?p=trips' 
                    class='px-6 py-3 bg-gradient-to-r from-purple-500 to-fuchsia-600 text-white font-semibold rounded-lg shadow-md hover:shadow-lg hover:opacity-90 transition duration-300'>
                    🚍 Ver Viajes
                </a>
            </div>
        </div>
    </div>

    </body>
    </html>
    ";
}

?>
