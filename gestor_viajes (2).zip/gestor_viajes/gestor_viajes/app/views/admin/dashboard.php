<?php require __DIR__ . '/../shared/header.php'; ?>

<!-- Panel de Administración con estilo moderno en Tailwind -->
<div class="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-100 via-indigo-200 to-purple-200 font-[Poppins]">
  
  <div class="bg-white/80 backdrop-blur-md shadow-2xl rounded-2xl p-10 w-full max-w-2xl text-center border border-white/40 transition-transform duration-300 hover:scale-[1.02]">
    
    <h2 class="text-3xl font-extrabold text-gray-800 mb-6 tracking-wide">
      🧭 Panel <span class="text-indigo-600">ADMIN</span>
    </h2>

    <p class="text-gray-600 text-lg mb-8">
      Bienvenido al panel de administración. Selecciona una opción para gestionar el sistema:
    </p>

    <div class="flex flex-wrap justify-center gap-4">
      <a href='?p=trips'
         class="px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-semibold rounded-lg shadow-md hover:shadow-lg hover:opacity-90 transition duration-300">
         🚍 Gestionar viajes
      </a>

      <a href='?p=users'
         class="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-semibold rounded-lg shadow-md hover:shadow-lg hover:opacity-90 transition duration-300">
         👤 Gestionar usuarios
      </a>

      <a href='?p=reservations'
         class="px-6 py-3 bg-gradient-to-r from-purple-500 to-fuchsia-600 text-white font-semibold rounded-lg shadow-md hover:shadow-lg hover:opacity-90 transition duration-300">
         📋 Ver reservas
      </a>
    </div>

  </div>

</div>

<?php require __DIR__ . '/../shared/footer.php'; ?>

